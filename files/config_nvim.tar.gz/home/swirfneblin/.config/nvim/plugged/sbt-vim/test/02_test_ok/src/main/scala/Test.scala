
object Test {

  val x : Int = 42;

}

