
import org.scalatest.FunSuite;

class Suite extends FunSuite {

  test("test") {
    assert(Test.x != 42);
  }

}

