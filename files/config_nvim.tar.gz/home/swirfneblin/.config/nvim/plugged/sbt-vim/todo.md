
To-Do
=====

* Better support for multi-line error messages

* Optionally run sbt from the directory which contains build.sbt

* Optionally include warnings

