<?php

namespace Foo;

class BarBaz {
}

