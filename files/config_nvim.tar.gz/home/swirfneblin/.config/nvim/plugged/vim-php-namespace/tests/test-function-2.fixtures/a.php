<?php

namespace Foo;

function bar() {
}

