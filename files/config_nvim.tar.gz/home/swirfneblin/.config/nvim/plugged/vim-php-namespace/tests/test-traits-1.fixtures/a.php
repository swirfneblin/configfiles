<?php

namespace Foo;

trait Bar {
}

