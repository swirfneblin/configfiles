import java.bla
import scala.horst

import AgentTypes._
import akka.actor.{Actor, ActorLogging, ActorRef, ActorRefFactory, ActorSystem, Props, Stash, Terminated}

class Bar
