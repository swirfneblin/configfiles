var p: Promise<void>

var a = { template: /*eee*/ this.template
}

type A = [
    /*test*/ string,
    /*test*/ string,
]

var b: unique symbol = 123

var c: readonly t.MyClass<T>[] = 333

c?.test

const COMPILER_PROVIDERS: Array<any[]> = null

var a = {
  get method<T>(a) {
  },
}

var a = [/\/\//, 123]

if (/*rete*/123) {}


if (a < (<number>b))
    a
}
while (
 // sdkfsld
  ss) {
}

var a: T[K] = 1213

switch (eww) {
  case 1222
}

var a = 123

class MyClass<string> extends Mixin({test: 123}) {
    noed // ewewe
    a = '3' // ewew
    get(arg: string) {
    }
}

var a = test[333]

function test({a = process.stdout}) {}

// test
var a = 1/3
/* test*/
type A = 42


test({
  async a: test ? // test
  test: ee
})

getSymbolIterator(3) in obj;


list.reduce((flat: any[], item: T | T[]): T[] => {
  const flatItem = Array.isArray(item) ? flatten(item) : item;
  return (<T[]>flat).concat(flatItem);
}, []);

export function noProviderError(injector: ReflectiveInjector, key: ReflectiveKey): InjectionError {
  return injectionError(injector, key, function(keys: ReflectiveKey[]) {
    const first = stringify(keys[0].token);
    return `No provider for ${first}!${constructResolvingPath(keys)}`;
  });
}


export class QueryList<T>/* implements Iterable<T> */ {
  public readonly dirty = true;
}


class A {
    a = (a: () => void) => { }
}

var a = ({a: () => 123})

enum A {

}

interface FooBar<T extends Record<string, any> = Record<string, any>> {
  foo: string;
  bar: number;
}
