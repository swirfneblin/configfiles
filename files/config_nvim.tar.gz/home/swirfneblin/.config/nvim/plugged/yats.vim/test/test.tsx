var fragment = <div sdss="123" ></div>
var b = <Div sss="123"></Div>
var a = 123
var a=  <Option key={item}></Option>;
var a=  <Option       key={item}
    value="test"
>
</Option>;

var a = <React.Fragment>
      {
        this.state.thing
          ? <p>Hello <strong data-role={`${this.props.prefix}-name`}>world</strong></p>
          : <h1>Hey!</h1>
      }

      <h1 className={`${this.props.baz}-class`}>wow</h1>
    </React.Fragment>


var a = <ion-gesture>
<div></div>
</ion-gesture>

var b = 123
var c = (
  <>
  <Route component={this.renderHome} />
  </>
)

class A {
  render() {
    var d = (
      <Link to="/" className={styles.logo} onClick={this.closeNavBar}>
        {this.renderStuff()}
      </Link>
    )
    return <Route exact/>
  }
}

// paren + function child
var d =  (
  <Route component={() => <Home/>}/>
)

